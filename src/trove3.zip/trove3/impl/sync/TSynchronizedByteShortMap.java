///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2008, Robert D. Eden All Rights Reserved.
// Copyright (c) 2009, Jeff Randall All Rights Reserved.
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
///////////////////////////////////////////////////////////////////////////////

package gnu.trove3.impl.sync;


//////////////////////////////////////////////////
// THIS IS A GENERATED CLASS. DO NOT HAND EDIT! //
//////////////////////////////////////////////////

////////////////////////////////////////////////////////////
// THIS IS AN IMPLEMENTATION CLASS. DO NOT USE DIRECTLY!  //
// Access to these methods should be through TCollections //
////////////////////////////////////////////////////////////


import gnu.trove3.*;
import gnu.trove3.function.*;
import gnu.trove3.iterator.*;
import gnu.trove3.map.*;
import gnu.trove3.procedure.*;
import gnu.trove3.set.*;

import java.util.Map;
import java.io.Serializable;
import java.io.ObjectOutputStream;
import java.io.IOException;


public class TSynchronizedByteShortMap implements TByteShortMap, Serializable {
	private static final long serialVersionUID = 1978198479659022715L;

	private final TByteShortMap m;     // Backing Map
	final Object      mutex;	// Object on which to synchronize

	public TSynchronizedByteShortMap( TByteShortMap m ) {
		if ( m == null )
			throw new NullPointerException();
		this.m = m;
		mutex = this;
	}

	public TSynchronizedByteShortMap( TByteShortMap m, Object mutex ) {
		this.m = m;
		this.mutex = mutex;
	}

	@Override
	public int size() {
		synchronized( mutex ) { return m.size(); }
	}
	@Override
	public boolean isEmpty(){
		synchronized( mutex ) { return m.isEmpty(); }
	}
	@Override
	public boolean containsKey( byte key ) {
		synchronized( mutex ) { return m.containsKey( key ); }
	}
	@Override
	public boolean containsValue( short value ){
		synchronized( mutex ) { return m.containsValue( value ); }
	}
	@Override
	public short get( byte key ) {
		synchronized( mutex ) { return m.get( key ); }
	}

	@Override
	public short put( byte key, short value ) {
		synchronized( mutex ) { return m.put( key, value ); }
	}
	@Override
	public short remove( byte key ) {
		synchronized( mutex ) { return m.remove( key ); }
	}
	@Override
	public void putAll( Map<? extends Byte, ? extends Short> map ) {
		synchronized( mutex ) { m.putAll( map ); }
	}
	@Override
	public void putAll( TByteShortMap map ) {
		synchronized( mutex ) { m.putAll( map ); }
	}
	@Override
	public void clear() {
		synchronized( mutex ) { m.clear(); }
	}

	private transient TByteSet keySet = null;
	private transient TShortCollection values = null;

	@Override
	public TByteSet keySet() {
		synchronized( mutex ) {
			if ( keySet == null )
				keySet = new TSynchronizedByteSet( m.keySet(), mutex );
			return keySet;
		}
	}
	@Override
	public byte[] keys() {
		synchronized( mutex ) { return m.keys(); }
	}
	@Override
	public byte[] keys( byte[] array ) {
		synchronized( mutex ) { return m.keys( array ); }
	}

	@Override
	public TShortCollection valueCollection() {
		synchronized( mutex ) {
			if ( values == null )
				values = new TSynchronizedShortCollection( m.valueCollection(), mutex );
			return values;
		}
	}
	@Override
	public short[] values() {
		synchronized( mutex ) { return m.values(); }
	}
	@Override
	public short[] values( short[] array ) {
		synchronized( mutex ) { return m.values( array ); }
	}

	@Override
	public TByteShortIterator iterator() {
		return m.iterator(); // Must be manually synched by user!
	}

	// these are unchanging over the life of the map, no need to lock
	@Override
	public byte getNoEntryKey() { return m.getNoEntryKey(); }
	@Override
	public short getNoEntryValue() { return m.getNoEntryValue(); }

	@Override
	public short putIfAbsent( byte key, short value ) {
		synchronized( mutex ) { return m.putIfAbsent( key, value ); }
	}
	@Override
	public boolean forEachKey( TByteProcedure procedure ) {
		synchronized( mutex ) { return m.forEachKey( procedure ); }
	}
	@Override
	public boolean forEachValue( TShortProcedure procedure ) {
		synchronized( mutex ) { return m.forEachValue( procedure ); }
	}
	@Override
	public boolean forEachEntry( TByteShortProcedure procedure ) {
		synchronized( mutex ) { return m.forEachEntry( procedure ); }
	}
	@Override
	public void transformValues( TShortFunction function ) {
		synchronized( mutex ) { m.transformValues( function ); }
	}
	@Override
	public boolean retainEntries( TByteShortProcedure procedure ) {
		synchronized( mutex ) { return m.retainEntries( procedure ); }
	}
	@Override
	public boolean increment( byte key ) {
		synchronized( mutex ) { return m.increment( key ); }
	}
	@Override
	public boolean adjustValue( byte key, short amount ) {
		synchronized( mutex ) { return m.adjustValue( key, amount ); }
	}
	@Override
	public short adjustOrPutValue( byte key, short adjust_amount, short put_amount ) {
		synchronized( mutex ) { return m.adjustOrPutValue( key, adjust_amount, put_amount ); }
	}

	@Override
	public boolean equals( Object o ) {
		synchronized( mutex ) { return m.equals( o ); }
	}
	@Override
	public int hashCode() {
		synchronized( mutex ) { return m.hashCode(); }
	}
	@Override
	public String toString() {
		synchronized( mutex ) { return m.toString(); }
	}
	private void writeObject( ObjectOutputStream s ) throws IOException {
		synchronized( mutex ) { s.defaultWriteObject(); }
	}
}
